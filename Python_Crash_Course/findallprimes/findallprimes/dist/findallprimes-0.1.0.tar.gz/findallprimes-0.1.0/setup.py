from setuptools import setup, find_packages
setup(
name='findallprimes',
version='0.1.0',
author='ARMAN',
description='This package finds all prime numbers from 2 to that number ',
packages=find_packages(),
classifiers=[
'Programming Language :: Python :: 3',
'License :: OSI Approved :: MIT License',
'Operating System :: OS Independent',
],
python_requires='>=3.6',
)