from distutils.core import setup

setup(
	name = 'findallprimes',
	version = '1.0.0',
	py_modules = ['findallprimes'],
	author = 'Arman',
	author_email = 'armanashraf015@gmail.com',
	description = 'This package finds all prime numbers from 2 to that number'
)

 
 